package com.ruoyi.common.constant;

public class TaskParamConstants {
	
	/**
	 * 任务状态00:处理中
	 */
	public static final String task_status_00 = "00";
	
	/**
	 * 任务状态08：处理失败
	 */
	public static final String task_status_08 = "08";
	
	/**
	 * 任务状态09：处理成功
	 */
	public static final String task_status_09 = "09";
	
}
