package com.ruoyi.common.constant;

public class OperParamConstant {

	
}
