package com.ruoyi.common.constant;

public class MsgTemplateConstants {

	//【RET】您的验证码是#code#。如非本人操作，请忽略本短信
	public static final String COMMON_TIP = "173775";

	//【RET】系统检测到你的账号登录ip地址变更，若正常操作请忽略
	public static final String ACCOUNT_LOGIN_TIP = "174041";
}
